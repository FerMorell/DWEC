function tabla() {
    let tabla = "<table>"
    for (let i = 0; i < 15; i++) {
        tabla += "<tr>"
        for (let j = 0; j < 15; j++) {
            tabla += '<td ></td>';
        }
        tabla += "</tr>"
    }
    tabla += "</table>"
    document.getElementById("tablear").innerHTML = tabla;
}
tabla();

let colorElegido;



document.getElementById("rojo").addEventListener("click", function () {
    colorElegido = "red";
});
document.getElementById("azul").addEventListener("click", function () {
    colorElegido = "azul";
}); document.getElementById("rosa").addEventListener("click", function () {
    colorElegido = "rosa";
}); document.getElementById("borrar").addEventListener("click", function () {
    colorElegido = "borrar";
});