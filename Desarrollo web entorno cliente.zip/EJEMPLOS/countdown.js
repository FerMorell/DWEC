const cont = document.getElementById("marcador");
const azulito = document.getElementById("principal");
let contador = 10;
let intervalo;/*Si necesito guardar*/

function descontar() {
    contador--;
    cont.innerText = contador;
    if (contador == 0) {
        clearInterval(intervalo);
        explotar();
        cont.innerText = "";

    }
}
function empezar() {
    intervalo = setInterval(descontar, 1000);

}
function explotar() {
    azulito.innerText = "BOOOM";
    contador = 10;
}

function cancelar() {
    clearInterval(intervalo);
    contador = 10;
    cont.innerText = "";
    azulito.innerText = "";
}