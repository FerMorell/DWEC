const rojo = document.getElementById("rojo");
const amarillo = document.getElementById("amarillo");
const verde = document.getElementById("verde");
let tiempo;
/*function empezar(){

}lo mismo de abajo*/
let empezar = () => {
    tiempo = setTimeout(() => {
        enRojo()
    }, 5000);
}
/*Son iguales la de arriba y abajo */

// function empezar() {
//     tiempo = setTimeout(enVerde, 500);
// }

function enRojo() {
    rojo.innerText = "Espere";
    tiempo = setTimeout(enAmarillo, 1500);
}

function enAmarillo() {
    amarillo.innerText = "Casi"
    tiempo = setTimeout(enVerde, 1000);
}

function enVerde() {
    verde.innerText = "Pase";
    tiempo = setTimeout(() => {

        rojo.innerText = "";
        amarillo.innerText = "";
        verde.innerText = "";

    }, 4000);
}


function parar() {
    clearTimeout(tiempo);
    rojo.innerText = "";
    amarillo.innerText = "";
    verde.innerText = "";

}
