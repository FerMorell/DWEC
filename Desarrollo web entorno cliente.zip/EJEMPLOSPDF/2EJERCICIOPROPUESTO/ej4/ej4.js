/*4. Realiza un programa que lea un numero N y
 muestre en el navegador todos los pares desde 2 hasta N (inclusive). Cada
número se mostrará en una línea distinta. N siempre sera mayor o igual a 2. */


const num = document.getElementById("numero");
const resultado = document.getElementById("numeritos");

function imprimirPares(t) {
    resultado.innerHTML = ""/*Lo hacemos para limpiar cada vez que lo vamos a utilizar */
    if (t >= 2) {
        for (let i = 2; i <= t; i++) {
            if (i % 2 == 0) {
                resultado.innerHTML += i + "<br>";
            }
        }
    } else {
        resultado.innerHinnerHTMLTML = "No has escrito nada, o el numero es menor a 2";
    }
}

function imprimir() {
    let dato = parseInt(num.value);
    imprimirPares(dato);
}