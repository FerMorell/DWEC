let sueldo=prompt("Introduce tu sueldo: ");
let anio=prompt("Introcude los años de antigü5edad: ");

if(sueldo<500 && anio>=10){
    sueldo=sueldo*3;
}else if(sueldo<500 && anio<10){
    sueldo=sueldo*2;
}

document.write("Sueldo: "+sueldo+" "+" Año: "+anio);