

const num = document.getElementById("numero");
const resultado = document.getElementById("resultado");

function imprimir(t) {
    resultado.innerHTML = " ";
    if (t >= 1) {
        for (let i = 0; i < t; i++) {
            if (i % 2 != 0) {
                resultado.innerHTML += i + "<br>";
            }
        }
    } else {
        resultado.innerHTML = "No has puesto un numero válido"
    }
}

/*5. Realiza un programa que lea un numero N y muestre muestre en el navegador todos los impares desde N(inclusive) hasta 1.
Cada número se mostrará en una línea distinta. N siempre sera mayor o igual a 1.
 */

function recibir() {
    let dato = parseInt(num.value);
    imprimir(dato);
}