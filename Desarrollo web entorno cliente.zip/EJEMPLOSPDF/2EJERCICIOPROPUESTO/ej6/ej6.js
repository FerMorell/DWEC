


const numero1 = document.getElementById("n1");
const numero2 = document.getElementById("n2");
let tabla = document.getElementById("tabla");

function tablas(x, y) {

    if (x <= 50 && x >= -50) {
        if (y <= 20 && y >= 1) {
            for (let i = 1; i <= y; i++) {

                tabla.innerHTML += "<br>" + x + " x " + i + " = " + (x * i) + "</br>";


            }
        }
    }

}

function recibirValores() {
    let num1 = parseInt(numero1.value);
    let num2 = parseInt(numero2.value);
    tablas(num1, num2);
}