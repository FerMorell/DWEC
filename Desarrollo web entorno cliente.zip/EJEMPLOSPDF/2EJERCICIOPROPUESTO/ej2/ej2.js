let nota=prompt("Introduce la nota: ");

if(nota<0 && nota >10){
    document.write("No has puesto una nota válida");
}else if(nota>=0 && nota<3){
    document.write("Muy deficiente");

}else if(nota>=3 && nota<=5){
    document.write("Insuficiente");

}else if(nota <5 && nota <6){
    document.write("Bien");

}else if(nota>=6 && nota <9){
    document.write("Notable");

}else if(nota >=9 && nota==10){
    document.write("Sobresaliente");

}