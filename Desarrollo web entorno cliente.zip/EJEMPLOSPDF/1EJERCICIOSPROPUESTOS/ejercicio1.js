"use strict";

const texto = document.getElementById("intxt");

const area = document.getElementById("lienzo");

function escribir(t) {
    if (t == "domingo") {
        area.textContent = "Has puesto domingo";
    } else {
        area.textContent = "No has puesto domingo";
    }

}

function activar() {
    let dato = texto.value;//texto.value es el texto que viene dentro
    escribir(dato);
}
