//alert("Hola, mundo");//Aparece al abrir 
console.log("Hola, mundito");//Aparece escrito en el html
document.write("Hola, mundo!")//Aparece en consola

/*
Son como los comentarios en java, distinto a los de html.
*/
//Recoge aquel objeto cuyo identificador sea ese es element
//porque el identificador es único.
//este devuelve el bloque en si , tiene propiedades,
//metodos, el div tendra su tamaño, color,etc..
//Nos interesa innerText que es el texto que contiene
//dentro.

/*
La forma más sencilla de meter datos nececitariamos 
una funcion prompt
*/
/*
 Antes se utilizaba var pero esta de desuso.
 
 Let -> indica el ambito en el que declara la variable,
 no es lo mismo declararlo dentro de un metodo que al principio.

 const-> Se utiliza para constantes valores que no cambian
 pero hay una excepcion podemos cambiar los valores colores, altura
 escribir, etc.. pero en si el objeto no cambia, cuando
 la creamos le damos el valor const miBloque=document..("mibloque").
 

"use strict"->  obliga a que todas las variables sean declaradas.
let nombre=prompt("Escribe tu nombre:");
console.log(nombre);
Para poder recoger la respuesta lo metemos en una variable
 */


const bloque1 = document.getElementById("bloque1");
const bloque2 = document.getElementById("bloque2");

/* bloque1.innerText="Hola,"+nombre;
bloque1.innerText +=", Buenas tardes"

bloque2.innerHTML="Hola,"+nombre;
bloque2.innerHTML +=", Buenas tardes" */
// Va machacando 
// document.getElementById("bloque1").innerText="Hola, mundo";

//Cuando hacemos algo que no es no numero por eso nos
//devuelve el NAN not a number
/* let resultado=3/"hola"
console.log("division con caracteres:"+resultado);


//Devuelve INFINITY porque al dividir por 0 da esa respuesta.
resultado=100/0;
console.log("Division por cero: "+resultado);

resultado=2**5;//** el doble asterisco es potencia 
console.log("potencia: "+resultado); */
/*
a=5
b='5'
== -> a==b este dara bien, controla el valor
=== -> a===b este no porque compara el tipo de dato , este controla el tipo

? -> a==b ? 5 :10
        si b es true le dara el valor 5 sino le dara el valor 10
        

*/

let texto1 = "Cosas originales";
let texto2 = "Segunda cosa original";
let textoFinal = texto1 + " : " + texto2;
bloque1.innerText = textoFinal;

let textoFinal2 = `${texto1} ........  ${texto2}.....${texto1 + texto2}`;
//Con `nos imprime el nombre de la variable pero con
// el $ nos imprime el valor de la variable
bloque2.innerText = textoFinal2;
let textofinal3 = `${texto1}
 ........ ${texto2}
 .....
 ${texto1 + texto2}`;

document.write(textofinal3);


let textofinal4 = `<h2>${texto1}</h2>
 ........ <p>${texto2}</p>
 <br></br>
 <p>${texto1 + texto2}</p>`;

document.write(textofinal4);//Si que reconoce las etiquetas HTML.
// bloque2.innerText=textofinal4; no reconoce las etiquetas
// HTML solo las pone sin más se ve FATAL.
bloque2.innerHTML = textofinal4;//En este si que reconoce las etiquetas HTML.



const bloque3 = document.getElementById("bloque3");

const miObjeto = {
        nombre: "pepe",
        edad: 24,
        telefono: "235654"
}

/*
El for in lo que hace es coger cada valor del objeto , tenemos campo valor, reocrremos todo los valores del objeto
el for x la x es como cada campo
 */
let valores = "";
let claves = "";
for (let o in miObjeto) {
        valores += miObjeto[o];
        claves += o;
}


bloque3.innerText = valores;
bloque3.innerText += "...." + claves;