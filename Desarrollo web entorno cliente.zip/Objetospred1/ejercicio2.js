

function negrita() {
    let palabrita = document.getElementById("palabra").value;
    let resul = document.getElementById("textocambiado");
    resul.innerHTML = '<strong>' + palabrita + '</strong>' + '<br>';
}
function parpadeante() {
    let palabrita = document.getElementById("palabra").value;
    let resul = document.getElementById("textocambiado");
    resul.innerHTML = '<span style="animation: blink 1s step-start infinite;">' + palabrita + '</span><br>';
}

function grande() {
    let palabrita = document.getElementById("palabra").value;

    let resul = document.getElementById("textocambiado");
    resul.innerHTML = '<span style="font-size: 2em;">' + palabrita + '</span><br>';
}

function mayusculas() {
    let palabrita = document.getElementById("palabra").value.toUpperCase();
    let resul = document.getElementById("textocambiado");
    resul.innerHTML = palabrita + '<br>';
}

function minusculas() {
    let palabrita = document.getElementById("palabra").value.toLowerCase();
    let resul = document.getElementById("textocambiado");
    resul.innerHTML = palabrita + '<br>';
}

function pequena() {
    let palabrita = document.getElementById("palabra").value;
    let resul = document.getElementById("textocambiado");
    resul.innerHTML = '<span style="font-size: 0.5em;">' + palabrita + '</span><br>';
}
