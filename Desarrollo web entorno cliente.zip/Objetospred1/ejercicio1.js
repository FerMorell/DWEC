/*3. Lo anterior y contar las ocurrencias sustituidas
4. Preguntar en cada ocurrencia si sustituye--> */
function buscarPrimera() {
    const texto = document.getElementById("texto").value; // Obtener el valor del textarea
    const palabraElegida = document.getElementById("palabraElegida").value; // Obtener la palabra a buscar
    const palabraCambiar = document.getElementById("palabraRemplazar").value; // Obtener la palabra de reemplazo

    let resultado = texto.replace(palabraElegida, palabraCambiar); // Reemplazar la primera coincidencia

    let textoCambiado = document.getElementById("textoCambiado");
    textoCambiado.innerText = resultado; // Mostrar el resultado
}

function sustituirTodas() {
    const texto = document.getElementById("texto").value;
    const palabraElegida = document.getElementById("palabraElegida").value;
    const palabraCambiar = document.getElementById("palabraRemplazar").value;
    let cambiar = new RegExp(palabraElegida, 'g');
    let resultado = texto.replace(cambiar, palabraCambiar);

    let textoCambiado = document.getElementById("textoCambiado");
    textoCambiado.innerText = resultado;
}
