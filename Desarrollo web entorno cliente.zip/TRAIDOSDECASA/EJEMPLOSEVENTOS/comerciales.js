// comercial,provincia,empresa 
const listacomerciales = `Stuart Senechell,Madrid,Microsoft
Dalila Padwick,Zaragoza,Coca-Cola
Symon Gottelier,Sevilla,Samsung
Ody Laffin,Barcelona,Samsung
Dill Ramelot,Sevilla,Samsung
Ricard Cooch,Murcia,Amazon
Lemmie Gaiger,Murcia,Samsung
Bill Tregonna,Málaga,Samsung
Ritchie Cocksedge,Zaragoza,Samsung
Sloan Chill,Málaga,Facebook
Hannah Wiffill,Málaga,Facebook
Jdavie Antos,Zaragoza,Samsung
Caresse Engeham,Sevilla,Microsoft
Cecilius Meekins,Málaga,Facebook
Che Reihill,Sevilla,Facebook
Hort Hathaway,Murcia,Walmart
Arabela Platts,Sevilla,Toyota
Gerick Wedlock,Sevilla,Coca-Cola
Worthy Cathesyed,Sevilla,Walmart
Celia Haseldine,Madrid,Disney
Tabina Trematick,Murcia,Samsung
Lee Agett,Bilbao,Samsung
Curcio Stapford,Valencia,Walmart
Kiley Larner,Málaga,Apple
Pryce Nettles,Valencia,Samsung
Eddie Savine,Bilbao,Coca-Cola
Kathi Van Leeuwen,Bilbao,Amazon
Perry Limming,Palma de Mallorca,Apple
Romy Rowcastle,Barcelona,Microsoft
Kermy Arundale,Valencia,Disney
Dyan Cleatherow,Las Palmas de Gran Canaria,Disney
Tait Pashba,Bilbao,Coca-Cola
Peggi Eyree,Sevilla,Microsoft
Lisetta Aspinal,Málaga,Samsung
Ingaberg Reeveley,Barcelona,Coca-Cola
Jackqueline Edgeon,Palma de Mallorca,Microsoft
Selene Libbe,Madrid,Amazon
Garwin Shillitoe,Sevilla,Microsoft
Abie O'Driscoll,Barcelona,Samsung
Hayyim Mullis,Málaga,Microsoft
Gunther Odam,Murcia,Coca-Cola
Ted Teml,Palma de Mallorca,Walmart
Merline Camlin,Valencia,Facebook
Maryanna Vasyunichev,Zaragoza,Toyota
Cristen Fouch,Málaga,Facebook`;
