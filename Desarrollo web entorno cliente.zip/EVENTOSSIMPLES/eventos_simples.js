const palabra = document.getElementById("palabra");
const texto = document.getElementById("texto");
const salida = document.getElementById("salida");
const start = document.getElementById("start");

const rojo = document.getElementById("rojo");
const verde = document.getElementById("verde");
const azul = document.getElementById("azul");
const dorado = document.getElementById("dorado");

let bloque = "";




function iniciarPagina() {
    dorado.addEventListener("contextmenu", (event) => {
        event.preventDefault();/*le quitamos los eventos que sucederian por defecto */
    });
}





function buscarPalabra() {
    let palabraAbuscar = palabra.value;
    let textoCompleto = texto.value;

    let hayPalabra = textoCompleto.indexOf(palabraAbuscar);

    if (hayPalabra != -1) {
        salida.innerText = "hay palabra";
    } else {
        salida.innerText = "Palabra no existente";
    }
}

function activaCuadro(miColor) {

    let mibloque = "";

    if (miColor == "dorado") {
        mibloque = miColor;
    }
    else {
        mibloque = bloque;
    }

    //mibloque = (micolor == null) ? bloque: micolor
    switch (mibloque) {
        case "rojo":
            salida.innerText = "Estas sobre el cuadro rojo";
            break;
        case "verde":
            salida.innerText = "Has salido del cuadro verde";
            break;
        case "azul":
            salida.innerText = "Has entrado en el cuadro azul";
            break;
        case "dorado":
            salida.innerText = "Has entrado en el amarillo"
            break;
        default:
            salida.innerText = "";
    }
}



start.addEventListener("click", buscarPalabra);

palabra.addEventListener("keyup", function () {
    palabra.style.backgroundColor = "lightpink";
    setTimeout(() => {
        palabra.style.backgroundColor = "white";
    }, 1000)
})/*Que cambie el color de fondo */


rojo.addEventListener("mouseover", () => {
    bloque = "rojo";
    activaCuadro();
})


verde.addEventListener("mouseleave", () => {
    bloque = "verde";
    activaCuadro();
})
azul.addEventListener("mouseenter", () => {
    bloque = "azul";
    activaCuadro();
})


dorado.addEventListener("mousemove", activaCuadro.bind(this, "dorado"));
dorado.addEventListener("contextmenu", () => {
    salida.innerText = "Has pulsado el boton derecho";
})/*el del click derecho */


iniciarPagina();