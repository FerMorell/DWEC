const mitexto = "Hola, Grupo :D";
//document.write(mitexto);
let i=0;
//es let porque es va a ir cambiando :P
function cambiaBloque() {
    const bloque1 = document.getElementById("bloque1");
    bloque1.innerText = mitexto;
    bloque1.style.backgroundColor = "salmon";
}

//alt para mover cosas :O
function escribeTexto() {
    document.write(mitexto);
    //es todo lo que esta en el body, reemplaza todo lo que haya con lo cual reemplaza todo
    console.log(mitexto);
}

function cambiaContador() {
    const bloque2 = document.getElementById("bloque2");
bloque2.innerText=i;
i +=1;
console.log(i);

}

