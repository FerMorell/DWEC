const dibujarTablero = document.getElementById("tablero");
const posicionEscrita = document.getElementById("posiciones").value.split('\n');
let tiempo = 60;
let intentos = 10;
let intervalo;
const posicionXLlave = Math.floor(Math.random() * (20 - 1 + 1)) + 1;
const posicionYLlave = Math.floor(Math.random() * (20 - 1 + 1)) + 1;
let posicion = posicionXLlave + ',' + posicionYLlave;
console.log(posicion);
const empezarTiempo = document.getElementById("crono");
function crearTablero() {
    let html = " ";
    html += '<table>';
    for (let i = 0; i < 20; i++) {
        html += '<tr>';
        for (let j = 0; j < 20; j++) {
            html += '<td class="celda"></td>';
        }
        html += '</tr>';
    }
    html += '</table>';
    dibujarTablero.innerHTML = html;
}

crearTablero();

function start() {
    empezarTiempo.textContent = tiempo;
    intervalo = setInterval(disminuirTiempo, 1000);
}




//NO  ME VA :C
function buscarLlave() {
    if (intentos <= 0) {
        terminarCronometro();
        document.getElementById("mensajes").innerHTML = 'Has superado los intentos!!';
    }
    let Imprimir = [];
    if (Array.isArray(posicionEscrita) && posicionEscrita.length > 0) {
        for (let i = 0; i < posicionEscrita.length; i++) {
            Imprimir[i] = posicionEscrita[i].split(",").map(Number);
            console.log(Imprimir[i]);
        }
    }

    intentos--;
}


function calcularDistancia(x, y) {
    return Math.sqrt(Math.pow(posicionXLlave - x, 2) + Math.pow(posicionYLlave - y, 2));
}

function disminuirTiempo() {
    tiempo--;
    document.getElementById("crono").innerHTML = tiempo;
    if (tiempo <= 0 || intentos <= 0) {
        clearInterval(intervalo);
        document.getElementById("mensajes").innerHTML = 'No has adivinado la llave en los intentos o se te ha terminado el tiempo :c ';
        terminarCronometro();
    }
}

function terminarCronometro() {
    clearInterval(intervalo);
}
